﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Aug26.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        chetu_dbEntities entities;
        public HomeController()
        {
            entities = new chetu_dbEntities();
        }
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
            var data = entities.Employees.ToList();
            return Json(data, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public ActionResult Create(Employee emp)
        {
            entities.Employees.Add(emp);
            entities.SaveChanges();
            return RedirectToAction("Index");
        }
        public ActionResult Delete(int id)
        {
            var data = entities.Employees.Find(id);
            entities.Employees.Remove(data);
            entities.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int id)
        {
            var data = entities.Employees.Find(id);
            return Json(data,JsonRequestBehavior.AllowGet);
        }
        public ActionResult Update(Employee emp)
        {
            entities.Entry(emp).State = System.Data.Entity.EntityState.Modified;
            entities.SaveChanges();
            return RedirectToAction("Index");
        }


    }
}